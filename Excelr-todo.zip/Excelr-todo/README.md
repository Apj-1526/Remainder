# Hooks:  pre defined functions to manipulate state
# Rules of Hooks: top of the scope