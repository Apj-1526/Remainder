const Tasks = [
        {
                id:1,
                desc:"Learn React js in a usefull manner with some amazing projects",
                date:"12/8/2023",
                completed:false,
                fav:true,
                deleted:false,
                imp:true
        },
        {
                id:2,
                desc:"Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magnam perspiciatis recusandae soluta doloribus porro delectus accusamus enim dolor.",
                date:"23/1/2021",
                completed:true,
                fav:false,
                deleted:false,
                imp:false
        },
        {
                id:3,
                desc:"I want to show only the first 3 lines of the paragraph below using HTML formatting. I am searching on W3Schools but it doesn't show how to do it.",
                date:"6/9/2022",
                completed:true,
                fav:true,
                deleted:true,
                imp:false
        },
        {
                id:4,
                desc:"The answer you've accepted wrong (it has no overflow specified so wouldn't hide anything), it would show 4 lines rather than 3 if it did. Why on earth was that marked as the correct answer? – James Donnelly",
                date:"5/7/2021",
                completed:false,
                fav:false,
                deleted:false,
                imp:false
        }
]

export default Tasks;